import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class magie here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Magie extends Angriff
{
    private static int projSpeed = 4;
    private static int damage = 50;
    
    public Magie(Enemy target){
        super(target);
        setImage("../images/angriffe/magie.png");
    }
    
    public void act() 
    {
        angreifen();
    }    
    /**
     * berechnent die Distanz zum Ziel
     * bewegt den Actor in Richtung des Ziels
     */
    public  void angreifen(){
        try {
            turnTowards(target.getX(), target.getY()); 
            move(projSpeed); 

            if(intersects(target)) { 
                target.attack(damage); 
                getWorld().removeObject(this); 
            }
        } catch(IllegalStateException e) {
            getWorld().removeObject(this); 
        }
    }   
}
