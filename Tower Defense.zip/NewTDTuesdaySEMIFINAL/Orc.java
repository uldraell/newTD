import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Normaler Gegner.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Orc extends Enemy
{
    private GreenfootImage orc1 = new GreenfootImage("../images/orc.png");
    private GreenfootImage orc2 = new GreenfootImage("../images/orc2.png");
    
    private int hp = 100;
    
    /**
     * @see Enemy
     */
    public Orc(Route route)
    {
        super(route);
        setImage(orc1);
    }

    public  void switchImage(Wegpunkt ziel){
        
        if (getImage() == orc1) 
        {
            setImage(orc2);
        }
        else
        {
            setImage(orc1);
        }
    }
    
    public int getID(){
         return 2;
        }
        
    public int getHP(){
        return hp;
    }
    
    public void setHP(int newHP){
        hp = newHP;
    }
    
    /**
     * @see Enemy
     */
    public int getBounty(){
        return 100;
    }
}
