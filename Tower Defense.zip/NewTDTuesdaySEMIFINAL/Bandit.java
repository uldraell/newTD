
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Schwächster Gegner.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bandit extends Enemy
{
    
     private GreenfootImage bandit1 = new GreenfootImage("../images/bandit1.png");
     private GreenfootImage bandit2 = new GreenfootImage("../images/bandit2.png");
     private int hp = 30;
     
     /**
      * @see Enemy
      */
     
     public Bandit(Route route)
     {     
        super(route);
        setImage(bandit1);
     }
     

     /**
      * @see Enemy
      */   
     public Bandit(Routenplaner route)
     {
         super(route);
         setImage(bandit1);
     }
     
     public  void switchImage(Wegpunkt ziel){
        
        if (getImage() == bandit1) 
        {
            setImage(bandit2);
        }
        else
        {
            setImage(bandit1);
        }
     }
     
     public int getID(){
         return 1;
        }
     
     public int getHP(){
        return hp;
     }
     
     public void setHP(int newHP){
        hp = newHP;
     }
     /**
      * @see Enemy
      */
      public int getBounty(){
        return 100;
     }
}
