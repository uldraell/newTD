import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot und MouseInfo)

/**
 * Turm auf dem sich MAgier befindet.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Tower2 extends TurretButton2
{
    
    public Tower2()
    {
        setImage("../images/tower/tower2.png");
    }
      
}